"""图片上传与管理 API"""
import os
import uuid
import time
from datetime import datetime
from flask import (
    Blueprint,
    request,
    jsonify,
    send_file,
    current_app,
    abort,
)
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
from ..models import User, Image
from ..extensions import db
from ..services.storage import LocalStorage, CloudBackupStorage
from ..services.image_processor import ImageProcessor

images_bp = Blueprint("images", __name__)


def allowed_file(filename):
    """检查文件扩展名是否允许"""
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_EXTENSIONS"]
    )


def generate_filename(original_name):
    """生成唯一文件名"""
    ext = original_name.rsplit(".", 1)[1].lower()
    timestamp = datetime.utcnow().strftime("%Y%m%d")
    unique_id = uuid.uuid4().hex[:12]
    return f"{timestamp}_{unique_id}.{ext}"


@images_bp.route("/upload", methods=["POST"])
@jwt_required()
def upload_image():
    """上传图片"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not user:
        return jsonify({"error": "用户不存在"}), 404

    if "file" not in request.files:
        return jsonify({"error": "未找到文件"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "未选择文件"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "不支持的文件格式"}), 400

    # 检查存储配额
    file.seek(0, os.SEEK_END)
    file_size = file.tell()
    file.seek(0)

    if user.storage_used + file_size > user.storage_quota:
        return jsonify({"error": "存储空间不足"}), 413

    # 生成文件名并保存
    original_name = secure_filename(file.filename) or "untitled"
    stored_filename = generate_filename(original_name)
    storage = LocalStorage()

    # 默认无损保存：直接保存原始文件，不做压缩
    final_path = os.path.join(current_app.config["UPLOAD_FOLDER"], stored_filename)
    file.save(final_path)

    original_size = os.path.getsize(final_path)
    final_size = original_size
    was_compressed = False

    # 仅在用户明确选择压缩时才执行
    do_compress = request.form.get("compress", "").lower() == "true" or current_app.config.get("COMPRESS_ON_UPLOAD", False)
    if do_compress:
        final_path, compressed_size, was_compressed = ImageProcessor.compress(
            final_path, final_path
        )
        final_size = os.path.getsize(final_path)

    # 获取图片信息
    img_info = ImageProcessor.get_image_info(final_path)

    # 生成缩略图
    thumbnail_name = None
    if current_app.config.get("GENERATE_THUMBNAIL", True):
        thumb_name = f"thumb_{stored_filename}"
        thumb_path = os.path.join(
            current_app.config["UPLOAD_FOLDER"], "thumbnails", thumb_name
        )
        if ImageProcessor.generate_thumbnail(final_path, thumb_path):
            thumbnail_name = thumb_name

    # 云备份
    cloud_url = None
    cloud_backed_up = False
    cloud_storage = CloudBackupStorage()
    if cloud_storage.enabled:
        cloud_key = f"images/{user_id}/{stored_filename}"
        cloud_url = cloud_storage.upload(final_path, cloud_key)
        if cloud_url:
            cloud_backed_up = True

    # 创建数据库记录
    ext = stored_filename.rsplit(".", 1)[1].lower()
    image = Image(
        public_id=str(uuid.uuid4()),
        user_id=user_id,
        original_name=original_name,
        filename=stored_filename,
        file_ext=ext,
        file_size=final_size,
        mime_type=file.content_type or f"image/{ext}",
        width=img_info["width"] if img_info else None,
        height=img_info["height"] if img_info else None,
        thumbnail_name=thumbnail_name,
        is_compressed=was_compressed,
        original_size=original_size if was_compressed else None,
        cloud_backed_up=cloud_backed_up,
        cloud_url=cloud_url,
        is_private=request.form.get("private", "false").lower() == "true",
    )

    db.session.add(image)

    # 更新用户存储用量
    user.storage_used += final_size

    db.session.commit()

    # 生成完整 URL 链接
    base_url = request.host_url.rstrip("/")
    return jsonify(
        {
            "message": "上传成功",
            "image": image.to_dict_with_links(base_url),
        }
    ), 201


@images_bp.route("/upload/batch", methods=["POST"])
@jwt_required()
def upload_batch():
    """批量上传图片"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not user:
        return jsonify({"error": "用户不存在"}), 404

    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "未找到文件"}), 400

    results = []
    errors = []
    storage = LocalStorage()

    for file in files:
        if file.filename == "" or not allowed_file(file.filename):
            errors.append({"filename": file.filename, "error": "无效文件"})
            continue

        original_name = secure_filename(file.filename) or "untitled"
        stored_filename = generate_filename(original_name)

        # 默认无损保存
        final_path = os.path.join(current_app.config["UPLOAD_FOLDER"], stored_filename)
        file.save(final_path)
        original_size = os.path.getsize(final_path)
        final_size = original_size
        was_compressed = False

        if user.storage_used + original_size > user.storage_quota:
            os.remove(final_path)
            errors.append({"filename": original_name, "error": "存储空间不足"})
            continue

        # 仅在用户选择压缩时执行
        do_compress = request.form.get("compress", "").lower() == "true" or current_app.config.get("COMPRESS_ON_UPLOAD", False)
        if do_compress:
            final_path, compressed_size, was_compressed = ImageProcessor.compress(final_path, final_path)
            final_size = os.path.getsize(final_path)

        img_info = ImageProcessor.get_image_info(final_path)

        thumbnail_name = None
        if current_app.config.get("GENERATE_THUMBNAIL", True):
            thumb_name = f"thumb_{stored_filename}"
            thumb_path = os.path.join(current_app.config["UPLOAD_FOLDER"], "thumbnails", thumb_name)
            if ImageProcessor.generate_thumbnail(final_path, thumb_path):
                thumbnail_name = thumb_name

        cloud_url = None
        cloud_backed_up = False
        cloud_storage = CloudBackupStorage()
        if cloud_storage.enabled:
            cloud_key = f"images/{user_id}/{stored_filename}"
            cloud_url = cloud_storage.upload(final_path, cloud_key)
            if cloud_url:
                cloud_backed_up = True

        ext = stored_filename.rsplit(".", 1)[1].lower()
        image = Image(
            public_id=str(uuid.uuid4()),
            user_id=user_id,
            original_name=original_name,
            filename=stored_filename,
            file_ext=ext,
            file_size=final_size,
            mime_type=file.content_type or f"image/{ext}",
            width=img_info["width"] if img_info else None,
            height=img_info["height"] if img_info else None,
            thumbnail_name=thumbnail_name,
            is_compressed=was_compressed,
            original_size=original_size if was_compressed else None,
            cloud_backed_up=cloud_backed_up,
            cloud_url=cloud_url,
        )

        db.session.add(image)
        user.storage_used += final_size
        results.append(image)

    db.session.commit()

    base_url = request.host_url.rstrip("/")
    return jsonify(
        {
            "message": f"成功上传 {len(results)} 张图片",
            "images": [img.to_dict_with_links(base_url) for img in results],
            "errors": errors,
        }
    ), 201


@images_bp.route("", methods=["GET"])
@jwt_required()
def list_images():
    """获取图片列表"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)
    per_page = min(per_page, 100)

    query = Image.query.filter_by(user_id=user_id)

    # 搜索
    search = request.args.get("search", "").strip()
    if search:
        query = query.filter(Image.original_name.ilike(f"%{search}%"))

    # 排序
    sort = request.args.get("sort", "newest")
    if sort == "oldest":
        query = query.order_by(Image.created_at.asc())
    elif sort == "largest":
        query = query.order_by(Image.file_size.desc())
    elif sort == "smallest":
        query = query.order_by(Image.file_size.asc())
    else:
        query = query.order_by(Image.created_at.desc())

    pagination = query.paginate(page=page, per_page=per_page, error_out=False)

    return jsonify(
        {
            "images": [img.to_dict() for img in pagination.items],
            "total": pagination.total,
            "pages": pagination.pages,
            "current_page": page,
            "per_page": per_page,
        }
    )


@images_bp.route("/<public_id>", methods=["GET"])
@jwt_required()
def get_image(public_id):
    """获取单张图片详情"""
    user_id = int(get_jwt_identity())
    image = Image.query.filter_by(public_id=public_id).first()

    if not image:
        return jsonify({"error": "图片不存在"}), 404

    if image.user_id != user_id:
        user = User.query.get(user_id)
        if not user.is_admin:
            return jsonify({"error": "无权访问"}), 403

    return jsonify({"image": image.to_dict()})


@images_bp.route("/<public_id>", methods=["DELETE"])
@jwt_required()
def delete_image(public_id):
    """删除图片"""
    user_id = int(get_jwt_identity())
    image = Image.query.filter_by(public_id=public_id).first()

    if not image:
        return jsonify({"error": "图片不存在"}), 404

    if image.user_id != user_id:
        user = User.query.get(user_id)
        if not user.is_admin:
            return jsonify({"error": "无权操作"}), 403

    storage = LocalStorage()

    # 删除本地文件
    storage.delete(image.filename)
    if image.thumbnail_name:
        storage.delete_thumbnail(image.filename)

    # 删除云端备份
    if image.cloud_backed_up:
        cloud_storage = CloudBackupStorage()
        cloud_key = f"images/{user_id}/{image.filename}"
        cloud_storage.delete(cloud_key)

    # 更新用户存储用量
    user = User.query.get(user_id)
    if user:
        user.storage_used = max(0, user.storage_used - image.file_size)

    db.session.delete(image)
    db.session.commit()

    return jsonify({"message": "删除成功"})


@images_bp.route("/batch/delete", methods=["POST"])
@jwt_required()
def batch_delete():
    """批量删除图片"""
    user_id = int(get_jwt_identity())
    data = request.get_json() or {}
    public_ids = data.get("ids", [])

    if not public_ids:
        return jsonify({"error": "未选择图片"}), 400

    storage = LocalStorage()
    deleted_count = 0
    errors = []

    for pid in public_ids:
        image = Image.query.filter_by(public_id=pid, user_id=user_id).first()
        if not image:
            errors.append({"id": pid, "error": "图片不存在或无权操作"})
            continue

        storage.delete(image.filename)
        if image.thumbnail_name:
            storage.delete_thumbnail(image.filename)

        if image.cloud_backed_up:
            cloud_storage = CloudBackupStorage()
            cloud_key = f"images/{user_id}/{image.filename}"
            cloud_storage.delete(cloud_key)

        user = User.query.get(user_id)
        if user:
            user.storage_used = max(0, user.storage_used - image.file_size)

        db.session.delete(image)
        deleted_count += 1

    db.session.commit()

    return jsonify(
        {
            "message": f"成功删除 {deleted_count} 张图片",
            "deleted_count": deleted_count,
            "errors": errors,
        }
    )


@images_bp.route("/<public_id>/convert", methods=["POST"])
@jwt_required()
def convert_image(public_id):
    """转换图片格式"""
    user_id = int(get_jwt_identity())
    image = Image.query.filter_by(public_id=public_id, user_id=user_id).first()

    if not image:
        return jsonify({"error": "图片不存在"}), 404

    data = request.get_json() or {}
    target_format = data.get("format", "").lower().lstrip(".")

    if target_format not in current_app.config["ALLOWED_EXTENSIONS"]:
        return jsonify({"error": "不支持的目标格式"}), 400

    if target_format == image.file_ext:
        return jsonify({"error": "图片已是该格式"}), 400

    storage = LocalStorage()
    src_path = storage.get_path(image.filename)

    if not os.path.exists(src_path):
        return jsonify({"error": "源文件不存在"}), 404

    new_filename = generate_filename(f"converted.{target_format}")
    new_path = storage.get_path(new_filename)

    if not ImageProcessor.convert_format(src_path, new_path, target_format):
        return jsonify({"error": "格式转换失败"}), 500

    new_size = os.path.getsize(new_path)

    # 生成新缩略图
    new_thumb_name = f"thumb_{new_filename}"
    new_thumb_path = os.path.join(
        current_app.config["UPLOAD_FOLDER"], "thumbnails", new_thumb_name
    )
    ImageProcessor.generate_thumbnail(new_path, new_thumb_path)

    # 删除旧文件
    storage.delete(image.filename)
    if image.thumbnail_name:
        storage.delete_thumbnail(image.filename)

    # 更新记录
    old_size = image.file_size
    image.filename = new_filename
    image.file_ext = target_format
    image.file_size = new_size
    image.thumbnail_name = new_thumb_name
    image.mime_type = f"image/{target_format}"

    img_info = ImageProcessor.get_image_info(new_path)
    if img_info:
        image.width = img_info["width"]
        image.height = img_info["height"]

    # 更新存储用量
    user = User.query.get(user_id)
    if user:
        user.storage_used = max(0, user.storage_used - old_size + new_size)

    # 云备份
    cloud_storage = CloudBackupStorage()
    if cloud_storage.enabled:
        cloud_key = f"images/{user_id}/{new_filename}"
        cloud_url = cloud_storage.upload(new_path, cloud_key)
        if cloud_url:
            image.cloud_backed_up = True
            image.cloud_url = cloud_url

    db.session.commit()

    return jsonify(
        {
            "message": "格式转换成功",
            "image": image.to_dict(),
        }
    )


@images_bp.route("/<public_id>/toggle-privacy", methods=["PATCH"])
@jwt_required()
def toggle_privacy(public_id):
    """切换图片公开/私密"""
    user_id = int(get_jwt_identity())
    image = Image.query.filter_by(public_id=public_id, user_id=user_id).first()

    if not image:
        return jsonify({"error": "图片不存在"}), 404

    image.is_private = not image.is_private
    db.session.commit()

    return jsonify(
        {
            "message": "已设为私密" if image.is_private else "已设为公开",
            "is_private": image.is_private,
        }
    )
