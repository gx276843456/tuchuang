"""统计信息 API"""
from collections import Counter
from datetime import datetime, timedelta
from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func
from ..models import User, Image
from ..extensions import db

stats_bp = Blueprint("stats", __name__)


@stats_bp.route("/overview", methods=["GET"])
@jwt_required()
def overview():
    """获取统计数据概览"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not user:
        return jsonify({"error": "用户不存在"}), 404

    # 基础统计
    total_images = Image.query.filter_by(user_id=user_id).count()
    total_size = (
        db.session.query(func.sum(Image.file_size))
        .filter_by(user_id=user_id)
        .scalar()
        or 0
    )
    total_views = (
        db.session.query(func.sum(Image.view_count))
        .filter_by(user_id=user_id)
        .scalar()
        or 0
    )
    compressed_images = Image.query.filter_by(user_id=user_id, is_compressed=True).count()
    cloud_backed_up = Image.query.filter_by(user_id=user_id, cloud_backed_up=True).count()

    # 存储使用率
    storage_quota = user.storage_quota or 0
    storage_usage_percent = (
        round((total_size / storage_quota * 100), 2) if storage_quota > 0 else 0
    )

    # 节省的空间 (通过压缩)
    saved_space = (
        db.session.query(func.sum(Image.original_size - Image.file_size))
        .filter_by(user_id=user_id, is_compressed=True)
        .scalar()
        or 0
    )

    return jsonify(
        {
            "total_images": total_images,
            "total_size": total_size,
            "total_size_display": format_size(total_size),
            "total_views": total_views,
            "compressed_images": compressed_images,
            "cloud_backed_up": cloud_backed_up,
            "saved_space": saved_space,
            "saved_space_display": format_size(saved_space),
            "storage_quota": storage_quota,
            "storage_quota_display": format_size(storage_quota),
            "storage_used": total_size,
            "storage_usage_percent": storage_usage_percent,
        }
    )


@stats_bp.route("/upload-trend", methods=["GET"])
@jwt_required()
def upload_trend():
    """获取近 30 天上传趋势"""
    user_id = int(get_jwt_identity())

    days = 30
    start_date = datetime.utcnow() - timedelta(days=days)

    results = (
        db.session.query(
            func.date(Image.created_at).label("date"),
            func.count(Image.id).label("count"),
            func.sum(Image.file_size).label("size"),
        )
        .filter(Image.user_id == user_id, Image.created_at >= start_date)
        .group_by(func.date(Image.created_at))
        .order_by(func.date(Image.created_at))
        .all()
    )

    # 填充空日期
    date_map = {str(r.date): {"count": r.count, "size": r.size or 0} for r in results}
    trend = []
    for i in range(days):
        date = (start_date + timedelta(days=i)).strftime("%Y-%m-%d")
        data = date_map.get(date, {"count": 0, "size": 0})
        trend.append(
            {
                "date": date,
                "count": data["count"],
                "size": data["size"],
                "size_display": format_size(data["size"]),
            }
        )

    return jsonify({"trend": trend})


@stats_bp.route("/format-distribution", methods=["GET"])
@jwt_required()
def format_distribution():
    """获取图片格式分布"""
    user_id = int(get_jwt_identity())

    results = (
        db.session.query(
            Image.file_ext,
            func.count(Image.id).label("count"),
            func.sum(Image.file_size).label("size"),
        )
        .filter_by(user_id=user_id)
        .group_by(Image.file_ext)
        .order_by(func.count(Image.id).desc())
        .all()
    )

    return jsonify(
        {
            "distribution": [
                {
                    "format": r.file_ext,
                    "count": r.count,
                    "size": r.size or 0,
                    "size_display": format_size(r.size or 0),
                }
                for r in results
            ]
        }
    )


@stats_bp.route("/recent", methods=["GET"])
@jwt_required()
def recent_uploads():
    """获取最近上传的图片"""
    user_id = int(get_jwt_identity())
    limit = 5

    images = (
        Image.query.filter_by(user_id=user_id)
        .order_by(Image.created_at.desc())
        .limit(limit)
        .all()
    )

    return jsonify({"images": [img.to_dict() for img in images]})


def format_size(size):
    """格式化文件大小"""
    if size is None:
        size = 0
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"
