"""应用配置模块"""
import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Config:
    """基础配置"""

    # Flask
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 单文件最大 50MB

    # 数据库
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'data', 'imagehost.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # JWT
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "jwt-secret-change-in-production")
    JWT_ACCESS_TOKEN_EXPIRES = 86400 * 7  # 7 天

    # 上传配置（可通过环境变量指向持久卷挂载路径）
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER") or os.path.join(BASE_DIR, "uploads")
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp", "bmp", "svg"}
    MAX_IMAGE_SIZE = 20 * 1024 * 1024  # 图片最大 20MB

    # 图片处理
    COMPRESS_ON_UPLOAD = os.environ.get("COMPRESS_ON_UPLOAD", "false").lower() == "true"
    COMPRESS_QUALITY = int(os.environ.get("COMPRESS_QUALITY", "85"))
    COMPRESS_MAX_WIDTH = int(os.environ.get("COMPRESS_MAX_WIDTH", "2048"))
    COMPRESS_MAX_HEIGHT = int(os.environ.get("COMPRESS_MAX_HEIGHT", "2048"))
    GENERATE_THUMBNAIL = True
    THUMBNAIL_SIZE = (300, 300)

    # 云备份配置 (S3 兼容: 阿里云OSS / 腾讯云COS / AWS S3)
    CLOUD_BACKUP_ENABLED = os.environ.get("CLOUD_BACKUP_ENABLED", "false").lower() == "true"
    CLOUD_ENDPOINT = os.environ.get("CLOUD_ENDPOINT", "")
    CLOUD_ACCESS_KEY = os.environ.get("CLOUD_ACCESS_KEY", "")
    CLOUD_SECRET_KEY = os.environ.get("CLOUD_SECRET_KEY", "")
    CLOUD_BUCKET = os.environ.get("CLOUD_BUCKET", "")
    CLOUD_REGION = os.environ.get("CLOUD_REGION", "")

    # 是否开启注册
    REGISTRATION_ENABLED = os.environ.get("REGISTRATION_ENABLED", "true").lower() == "true"


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


config_map = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
}
