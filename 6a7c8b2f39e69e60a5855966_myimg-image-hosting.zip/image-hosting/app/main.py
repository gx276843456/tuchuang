"""主路由 - 页面渲染与图片访问"""
import os
from flask import (
    Blueprint,
    render_template,
    send_file,
    request,
    jsonify,
    redirect,
    url_for,
    abort,
)
from flask_jwt_extended import jwt_required, get_jwt_identity, verify_jwt_in_request
from .models import Image, User
from .extensions import db
from .services.storage import LocalStorage

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """首页"""
    return render_template("index.html")


@main_bp.route("/login")
def login_page():
    """登录页"""
    return render_template("login.html")


@main_bp.route("/register")
def register_page():
    """注册页"""
    return render_template("register.html")


@main_bp.route("/dashboard")
def dashboard_page():
    """管理后台"""
    return render_template("dashboard.html")


@main_bp.route("/i/<public_id>")
def serve_image(public_id):
    """图片访问端点 (公开/私密)"""
    image = Image.query.filter_by(public_id=public_id).first()

    if not image:
        abort(404)

    # 私密图片需要登录验证
    if image.is_private:
        try:
            verify_jwt_in_request()
            user_id = int(get_jwt_identity())
            if user_id != image.user_id:
                abort(403)
        except Exception:
            abort(403)

    # 增加浏览次数
    image.view_count = (image.view_count or 0) + 1
    db.session.commit()

    storage = LocalStorage()
    thumb = request.args.get("thumb", "0") == "1"

    if thumb and image.thumbnail_name:
        thumb_path = os.path.join(
            storage.upload_folder, "thumbnails", image.thumbnail_name
        )
        if os.path.exists(thumb_path):
            return send_file(thumb_path, mimetype=image.mime_type)

    file_path = storage.get_path(image.filename)
    if not os.path.exists(file_path):
        abort(404)

    return send_file(file_path, mimetype=image.mime_type)


@main_bp.route("/api/images/<public_id>/download")
def download_image(public_id):
    """下载图片"""
    image = Image.query.filter_by(public_id=public_id).first()

    if not image:
        return jsonify({"error": "图片不存在"}), 404

    if image.is_private:
        try:
            verify_jwt_in_request()
            user_id = int(get_jwt_identity())
            if user_id != image.user_id:
                abort(403)
        except Exception:
            abort(403)

    storage = LocalStorage()
    file_path = storage.get_path(image.filename)

    if not os.path.exists(file_path):
        return jsonify({"error": "文件不存在"}), 404

    return send_file(
        file_path,
        as_attachment=True,
        download_name=image.original_name,
        mimetype=image.mime_type,
    )


@main_bp.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "接口不存在"}), 404
    return render_template("404.html"), 404


@main_bp.errorhandler(413)
def too_large(e):
    return jsonify({"error": "文件过大，超出限制"}), 413
