"""存储服务 - 本地存储 + 云备份"""
import os
import io
import logging
from flask import current_app

logger = logging.getLogger(__name__)


class LocalStorage:
    """本地文件存储"""

    def __init__(self, upload_folder=None):
        self.upload_folder = upload_folder or current_app.config["UPLOAD_FOLDER"]

    def save(self, file_storage, filename):
        """保存文件到本地"""
        filepath = os.path.join(self.upload_folder, filename)
        file_storage.save(filepath)
        return filepath

    def save_bytes(self, data, filename):
        """保存字节数据到本地"""
        filepath = os.path.join(self.upload_folder, filename)
        with open(filepath, "wb") as f:
            f.write(data)
        return filepath

    def get_path(self, filename):
        """获取文件路径"""
        return os.path.join(self.upload_folder, filename)

    def get_thumbnail_path(self, filename):
        """获取缩略图路径"""
        return os.path.join(self.upload_folder, "thumbnails", filename)

    def exists(self, filename):
        """检查文件是否存在"""
        return os.path.exists(self.get_path(filename))

    def delete(self, filename):
        """删除文件"""
        path = self.get_path(filename)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def delete_thumbnail(self, filename):
        """删除缩略图"""
        path = self.get_thumbnail_path(filename)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def get_size(self, filename):
        """获取文件大小"""
        path = self.get_path(filename)
        if os.path.exists(path):
            return os.path.getsize(path)
        return 0


class CloudBackupStorage:
    """云备份存储 (S3 兼容)"""

    def __init__(self):
        self.enabled = current_app.config.get("CLOUD_BACKUP_ENABLED", False)
        self.client = None

        if self.enabled:
            try:
                import boto3
                from botocore.config import Config as BotoConfig

                self.client = boto3.client(
                    "s3",
                    endpoint_url=current_app.config.get("CLOUD_ENDPOINT"),
                    aws_access_key_id=current_app.config.get("CLOUD_ACCESS_KEY"),
                    aws_secret_access_key=current_app.config.get("CLOUD_SECRET_KEY"),
                    region_name=current_app.config.get("CLOUD_REGION"),
                    config=BotoConfig(signature_version="s3v4"),
                )
                self.bucket = current_app.config.get("CLOUD_BUCKET")
                logger.info("云备份存储已初始化")
            except Exception as e:
                logger.error(f"云备份初始化失败: {e}")
                self.enabled = False

    def upload(self, filepath, cloud_key):
        """上传文件到云端"""
        if not self.enabled or not self.client:
            return False

        try:
            self.client.upload_file(filepath, self.bucket, cloud_key)
            cloud_url = f"{current_app.config.get('CLOUD_ENDPOINT')}/{self.bucket}/{cloud_key}"
            logger.info(f"文件已备份到云端: {cloud_key}")
            return cloud_url
        except Exception as e:
            logger.error(f"云备份失败: {e}")
            return False

    def upload_bytes(self, data, cloud_key, content_type="image/png"):
        """上传字节数据到云端"""
        if not self.enabled or not self.client:
            return False

        try:
            self.client.put_object(
                Bucket=self.bucket,
                Key=cloud_key,
                Body=data,
                ContentType=content_type,
            )
            cloud_url = f"{current_app.config.get('CLOUD_ENDPOINT')}/{self.bucket}/{cloud_key}"
            return cloud_url
        except Exception as e:
            logger.error(f"云备份失败: {e}")
            return False

    def delete(self, cloud_key):
        """从云端删除文件"""
        if not self.enabled or not self.client:
            return False

        try:
            self.client.delete_object(Bucket=self.bucket, Key=cloud_key)
            return True
        except Exception as e:
            logger.error(f"云端删除失败: {e}")
            return False


def get_storage():
    """获取本地存储实例"""
    return LocalStorage()


def get_cloud_storage():
    """获取云备份存储实例"""
    return CloudBackupStorage()
