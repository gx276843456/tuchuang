"""图片处理服务 - 压缩、格式转换、缩略图生成"""
import io
import os
from PIL import Image as PILImage
from flask import current_app


class ImageProcessor:
    """图片处理器"""

    SUPPORTED_FORMATS = {
        "jpg": "JPEG",
        "jpeg": "JPEG",
        "png": "PNG",
        "gif": "GIF",
        "webp": "WEBP",
        "bmp": "BMP",
    }

    @staticmethod
    def get_image_info(filepath):
        """获取图片信息"""
        try:
            with PILImage.open(filepath) as img:
                return {
                    "width": img.width,
                    "height": img.height,
                    "format": img.format,
                    "mode": img.mode,
                }
        except Exception:
            return None

    @staticmethod
    def compress(filepath, output_path=None, quality=None, max_width=None, max_height=None):
        """
        压缩图片
        返回: (输出路径, 压缩后大小, 是否实际压缩)
        """
        quality = quality or current_app.config["COMPRESS_QUALITY"]
        max_width = max_width or current_app.config["COMPRESS_MAX_WIDTH"]
        max_height = max_height or current_app.config["COMPRESS_MAX_HEIGHT"]

        if output_path is None:
            output_path = filepath

        original_size = os.path.getsize(filepath)

        try:
            with PILImage.open(filepath) as img:
                # 处理 RGBA 转 RGB (JPEG 不支持透明通道)
                if img.mode in ("RGBA", "P") and filepath.lower().endswith((".jpg", ".jpeg")):
                    background = PILImage.new("RGB", img.size, (255, 255, 255))
                    if img.mode == "P":
                        img = img.convert("RGBA")
                    background.paste(img, mask=img.split()[-1] if img.mode == "RGBA" else None)
                    img = background
                elif img.mode not in ("RGB", "RGBA", "L"):
                    img = img.convert("RGB")

                # 按比例缩放
                w, h = img.size
                if w > max_width or h > max_height:
                    ratio = min(max_width / w, max_height / h)
                    new_size = (int(w * ratio), int(h * ratio))
                    img = img.resize(new_size, PILImage.LANCZOS)

                # 保存压缩
                ext = os.path.splitext(filepath)[1].lower().lstrip(".")
                save_format = ImageProcessor.SUPPORTED_FORMATS.get(ext, "JPEG")

                save_kwargs = {}
                if save_format == "JPEG":
                    save_kwargs = {"quality": quality, "optimize": True}
                elif save_format == "PNG":
                    save_kwargs = {"optimize": True}
                elif save_format == "WEBP":
                    save_kwargs = {"quality": quality, "method": 6}

                img.save(output_path, format=save_format, **save_kwargs)

                compressed_size = os.path.getsize(output_path)
                was_compressed = compressed_size < original_size

                # 如果压缩后反而更大，保留原文件
                if not was_compressed and output_path == filepath:
                    return filepath, original_size, False

                return output_path, compressed_size, was_compressed

        except Exception as e:
            return filepath, original_size, False

    @staticmethod
    def generate_thumbnail(filepath, thumb_path, size=None):
        """生成缩略图"""
        size = size or current_app.config["THUMBNAIL_SIZE"]

        try:
            with PILImage.open(filepath) as img:
                img.thumbnail(size, PILImage.LANCZOS)

                # 转换模式
                if img.mode not in ("RGB", "RGBA", "L"):
                    img = img.convert("RGB")

                ext = os.path.splitext(thumb_path)[1].lower().lstrip(".")
                save_format = ImageProcessor.SUPPORTED_FORMATS.get(ext, "JPEG")

                save_kwargs = {}
                if save_format == "JPEG":
                    save_kwargs = {"quality": 80, "optimize": True}
                elif save_format == "WEBP":
                    save_kwargs = {"quality": 80}

                img.save(thumb_path, format=save_format, **save_kwargs)
                return True
        except Exception:
            return False

    @staticmethod
    def convert_format(filepath, output_path, target_format):
        """
        转换图片格式
        target_format: jpg, png, webp 等
        """
        target_format = target_format.lower().lstrip(".")
        save_format = ImageProcessor.SUPPORTED_FORMATS.get(target_format)

        if not save_format:
            return False

        try:
            with PILImage.open(filepath) as img:
                if save_format == "JPEG" and img.mode in ("RGBA", "P"):
                    background = PILImage.new("RGB", img.size, (255, 255, 255))
                    if img.mode == "P":
                        img = img.convert("RGBA")
                    background.paste(img, mask=img.split()[-1] if img.mode == "RGBA" else None)
                    img = background
                elif img.mode not in ("RGB", "RGBA", "L"):
                    img = img.convert("RGB")

                save_kwargs = {}
                if save_format == "JPEG":
                    save_kwargs = {"quality": 90, "optimize": True}
                elif save_format == "WEBP":
                    save_kwargs = {"quality": 90}

                img.save(output_path, format=save_format, **save_kwargs)
                return True
        except Exception:
            return False

    @staticmethod
    def serve_image(filepath, thumbnail=False, max_size=None):
        """读取图片为字节数据 (用于响应)"""
        try:
            if thumbnail:
                thumb_path = os.path.join(
                    os.path.dirname(os.path.dirname(filepath)),
                    "thumbnails",
                    os.path.basename(filepath),
                )
                if os.path.exists(thumb_path):
                    filepath = thumb_path

            with open(filepath, "rb") as f:
                return f.read()
        except Exception:
            return None
