"""Flask 应用工厂"""
import os
from flask import Flask
from .config import config_map
from .extensions import db, jwt, migrate, cors


def create_app(config_name=None):
    """创建 Flask 应用实例"""
    if config_name is None:
        config_name = os.environ.get("FLASK_ENV", "development")

    app = Flask(__name__, static_folder="../static", template_folder="templates")
    app.config.from_object(config_map[config_name])

    # 确保上传目录存在
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    thumb_dir = os.path.join(app.config["UPLOAD_FOLDER"], "thumbnails")
    os.makedirs(thumb_dir, exist_ok=True)

    # 确保数据库目录存在
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
    os.makedirs(data_dir, exist_ok=True)

    # 初始化扩展
    db.init_app(app)
    jwt.init_app(app)
    migrate.init_app(app, db)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})

    # 注册蓝图
    from .auth.routes import auth_bp
    from .api.images import images_bp
    from .api.stats import stats_bp
    from .main import main_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(images_bp, url_prefix="/api/images")
    app.register_blueprint(stats_bp, url_prefix="/api/stats")
    app.register_blueprint(main_bp)

    # 创建数据库表
    with app.app_context():
        db.create_all()

    return app
