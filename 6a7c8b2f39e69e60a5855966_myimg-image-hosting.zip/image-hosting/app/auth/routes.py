"""用户认证路由"""
from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import (
    create_access_token,
    jwt_required,
    get_jwt_identity,
)
from ..models import User
from ..extensions import db

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["POST"])
def register():
    """用户注册"""
    if not current_app.config.get("REGISTRATION_ENABLED", True):
        return jsonify({"error": "注册功能已关闭"}), 403

    data = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")
    email = data.get("email", "").strip() or None

    if not username or not password:
        return jsonify({"error": "用户名和密码不能为空"}), 400

    if len(username) < 3:
        return jsonify({"error": "用户名至少 3 个字符"}), 400

    if len(password) < 6:
        return jsonify({"error": "密码至少 6 个字符"}), 400

    if User.query.filter_by(username=username).first():
        return jsonify({"error": "用户名已存在"}), 409

    if email and User.query.filter_by(email=email).first():
        return jsonify({"error": "邮箱已被注册"}), 409

    # 第一个用户设为管理员
    is_admin = User.query.count() == 0

    user = User(username=username, email=email, is_admin=is_admin)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    access_token = create_access_token(identity=str(user.id))

    return jsonify(
        {
            "message": "注册成功",
            "token": access_token,
            "user": user.to_dict(),
        }
    ), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    """用户登录"""
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not username or not password:
        return jsonify({"error": "用户名和密码不能为空"}), 400

    user = User.query.filter_by(username=username).first()

    if not user or not user.check_password(password):
        return jsonify({"error": "用户名或密码错误"}), 401

    access_token = create_access_token(identity=str(user.id))

    return jsonify(
        {
            "message": "登录成功",
            "token": access_token,
            "user": user.to_dict(),
        }
    )


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def get_me():
    """获取当前用户信息"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not user:
        return jsonify({"error": "用户不存在"}), 404

    return jsonify({"user": user.to_dict()})


@auth_bp.route("/change-password", methods=["POST"])
@jwt_required()
def change_password():
    """修改密码"""
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)

    if not user:
        return jsonify({"error": "用户不存在"}), 404

    data = request.get_json() or {}
    old_password = data.get("old_password", "")
    new_password = data.get("new_password", "")

    if not user.check_password(old_password):
        return jsonify({"error": "原密码错误"}), 400

    if len(new_password) < 6:
        return jsonify({"error": "新密码至少 6 个字符"}), 400

    user.set_password(new_password)
    db.session.commit()

    return jsonify({"message": "密码修改成功"})
