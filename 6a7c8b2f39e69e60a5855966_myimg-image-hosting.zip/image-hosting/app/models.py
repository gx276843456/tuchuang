"""数据库模型"""
import os
import uuid
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from .extensions import db


class User(db.Model):
    """用户模型"""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    storage_quota = db.Column(db.BigInteger, default=1024 * 1024 * 1024)  # 默认 1GB
    storage_used = db.Column(db.BigInteger, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    images = db.relationship("Image", backref="owner", lazy="dynamic", cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "is_admin": self.is_admin,
            "storage_quota": self.storage_quota,
            "storage_used": self.storage_used,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class Image(db.Model):
    """图片模型"""

    __tablename__ = "images"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, nullable=False, index=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)

    # 文件信息
    original_name = db.Column(db.String(255), nullable=False)
    filename = db.Column(db.String(255), nullable=False)  # 存储的文件名
    file_ext = db.Column(db.String(10), nullable=False)
    file_size = db.Column(db.BigInteger, nullable=False)
    mime_type = db.Column(db.String(100), nullable=False)

    # 图片元数据
    width = db.Column(db.Integer, nullable=True)
    height = db.Column(db.Integer, nullable=True)
    thumbnail_name = db.Column(db.String(255), nullable=True)

    # 存储状态
    is_compressed = db.Column(db.Boolean, default=False)
    original_size = db.Column(db.BigInteger, nullable=True)  # 压缩前大小
    cloud_backed_up = db.Column(db.Boolean, default=False)
    cloud_url = db.Column(db.String(500), nullable=True)

    # 访问控制
    is_private = db.Column(db.Boolean, default=False)

    # 统计
    view_count = db.Column(db.Integer, default=0)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    def to_dict(self, include_url=True):
        data = {
            "id": self.id,
            "public_id": self.public_id,
            "original_name": self.original_name,
            "filename": self.filename,
            "file_ext": self.file_ext,
            "file_size": self.file_size,
            "mime_type": self.mime_type,
            "width": self.width,
            "height": self.height,
            "is_compressed": self.is_compressed,
            "original_size": self.original_size,
            "is_private": self.is_private,
            "view_count": self.view_count,
            "cloud_backed_up": self.cloud_backed_up,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
        if include_url:
            data["url"] = f"/i/{self.public_id}"
            data["thumbnail_url"] = f"/i/{self.public_id}?thumb=1"
            data["download_url"] = f"/api/images/{self.public_id}/download"
        return data

    def to_dict_with_links(self, base_url=""):
        """返回包含完整 URL 链接的字典（用于上传响应）"""
        data = self.to_dict()
        full_base = base_url.rstrip("/") if base_url else ""
        data["direct_url"] = f"{full_base}/i/{self.public_id}"
        data["markdown"] = f"![{self.original_name}]({full_base}/i/{self.public_id})"
        data["html"] = f'<img src="{full_base}/i/{self.public_id}" alt="{self.original_name}">'
        data["bbcode"] = f"[img]{full_base}/i/{self.public_id}[/img]"
        return data
