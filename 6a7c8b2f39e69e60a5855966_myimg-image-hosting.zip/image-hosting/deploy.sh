#!/bin/bash
#============================================
# MyImg 图床 - 一键部署脚本
# 支持三种模式: docker / direct / dev
#============================================
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

print_info()  { echo -e "${CYAN}[INFO]${NC}  $1"; }
print_ok()    { echo -e "${GREEN}[OK]${NC}    $1"; }
print_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

#============================================
# 显示帮助
#============================================
show_help() {
    cat << EOF
MyImg 图床部署脚本

用法:
  ./deploy.sh docker     Docker 容器化部署 (推荐)
  ./deploy.sh direct     直接部署 (Gunicorn + Nginx)
  ./deploy.sh dev        开发模式运行
  ./deploy.sh stop       停止 Docker 服务
  ./deploy.sh logs       查看 Docker 日志
  ./deploy.sh ssl        申请 SSL 证书 (需要先配置域名)

选项:
  --domain  DOMAIN       指定域名
  --port    PORT         指定端口 (默认 5000)
  -h, --help             显示帮助

示例:
  ./deploy.sh docker --domain img.example.com
  ./deploy.sh direct --port 8080
  ./deploy.sh dev
EOF
}

#============================================
# 检查依赖
#============================================
check_command() {
    if ! command -v "$1" &> /dev/null; then
        print_error "未找到命令: $1"
        print_info "请先安装: $2"
        exit 1
    fi
}

#============================================
# 初始化配置
#============================================
init_config() {
    if [ ! -f .env ]; then
        print_info "创建 .env 配置文件..."
        cp .env.example .env

        # 生成随机密钥
        SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null || openssl rand -hex 32)
        JWT_SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null || openssl rand -hex 32)

        sed -i "s/your-secret-key-here/$SECRET/" .env
        sed -i "s/your-jwt-secret-here/$JWT_SECRET/" .env

        if [ -n "$DOMAIN" ]; then
            print_info "设置域名: $DOMAIN"
        fi

        print_ok ".env 配置文件已创建"
    else
        print_warn ".env 已存在，跳过创建"
    fi

    # 创建必要目录
    mkdir -p uploads/thumbnails data
}

#============================================
# Docker 部署
#============================================
deploy_docker() {
    print_info "=== Docker 容器化部署 ==="

    check_command "docker" "https://docs.docker.com/engine/install/"
    check_command "docker-compose" "https://docs.docker.com/compose/install/" \
        || check_command "docker compose" "Docker Compose V2"

    init_config

    print_info "构建 Docker 镜像..."
    if docker compose version &> /dev/null; then
        docker compose build
    else
        docker-compose build
    fi

    print_info "启动容器..."
    if docker compose version &> /dev/null; then
        docker compose up -d
    else
        docker-compose up -d
    fi

    sleep 3

    # 检查容器状态
    if docker compose version &> /dev/null; then
        STATUS=$(docker compose ps --format json 2>/dev/null | python3 -c "
import sys, json
for line in sys.stdin:
    try:
        d = json.loads(line)
        print(f\"{d.get('Service', '?')}: {d.get('State', '?')}\")
    except: pass
" 2>/dev/null || docker compose ps)
    else
        STATUS=$(docker-compose ps)
    fi

    print_ok "Docker 部署完成!"
    echo ""
    echo "服务状态:"
    echo "$STATUS"
    echo ""
    print_info "访问地址: http://localhost:${PORT:-80}"
    print_info "查看日志: ./deploy.sh logs"
    print_info "停止服务: ./deploy.sh stop"
}

#============================================
# 直接部署 (Gunicorn + Nginx)
#============================================
deploy_direct() {
    print_info "=== 直接部署 (Gunicorn + Nginx) ==="

    check_command "python3" "https://www.python.org/downloads/"
    check_command "pip3" "通常随 Python 一起安装"

    init_config

    # 安装 Python 依赖
    print_info "安装 Python 依赖..."
    pip3 install -r requirements.txt --break-system-packages 2>/dev/null \
        || pip3 install -r requirements.txt

    # 安装 Gunicorn
    print_info "安装 Gunicorn..."
    pip3 install gunicorn --break-system-packages 2>/dev/null \
        || pip3 install gunicorn

    # 创建 systemd 服务
    print_info "创建 systemd 服务..."
    sudo tee /etc/systemd/system/myimg.service > /dev/null << EOF
[Unit]
Description=MyImg Image Hosting Service
After=network.target

[Service]
Type=exec
User=$(whoami)
WorkingDirectory=$PROJECT_DIR
EnvironmentFile=$PROJECT_DIR/.env
Environment=FLASK_ENV=production
ExecStart=$(which gunicorn) -c gunicorn_config.py "run:app"
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable myimg
    sudo systemctl restart myimg

    print_ok "MyImg 服务已启动"

    # 配置 Nginx
    if command -v nginx &> /dev/null; then
        print_info "配置 Nginx..."
        sudo cp nginx/conf.d/myimg.conf /etc/nginx/conf.d/myimg.conf 2>/dev/null || true
        sudo nginx -t && sudo systemctl reload nginx
        print_ok "Nginx 已配置"
    else
        print_warn "未安装 Nginx，直接通过端口 ${PORT:-5000} 访问"
    fi

    print_ok "部署完成!"
    echo ""
    print_info "访问地址: http://localhost:${PORT:-5000}"
    print_info "查看状态: sudo systemctl status myimg"
    print_info "查看日志: sudo journalctl -u myimg -f"
    print_info "重启服务: sudo systemctl restart myimg"
}

#============================================
# 开发模式
#============================================
deploy_dev() {
    print_info "=== 开发模式 ==="

    init_config

    print_info "安装依赖..."
    pip3 install -r requirements.txt --break-system-packages 2>/dev/null \
        || pip3 install -r requirements.txt

    print_info "启动开发服务器..."
    print_info "访问地址: http://localhost:${PORT:-5000}"
    print_warn "按 Ctrl+C 停止"

    FLASK_ENV=development python3 run.py
}

#============================================
# 停止 Docker 服务
#============================================
stop_docker() {
    print_info "停止 Docker 服务..."
    if docker compose version &> /dev/null; then
        docker compose down
    else
        docker-compose down
    fi
    print_ok "服务已停止"
}

#============================================
# 查看日志
#============================================
show_logs() {
    if docker compose version &> /dev/null; then
        docker compose logs -f --tail=100
    else
        docker-compose logs -f --tail=100
    fi
}

#============================================
# 申请 SSL 证书
#============================================
setup_ssl() {
    if [ -z "$DOMAIN" ]; then
        print_error "请指定域名: ./deploy.sh ssl --domain img.example.com"
        exit 1
    fi

    print_info "为域名 $DOMAIN 申请 SSL 证书..."

    mkdir -p certbot/conf certbot/www

    # 先用 HTTP 模式启动 Nginx
    print_info "临时启动 Nginx (HTTP)..."
    cat > nginx/conf.d/myimg.conf << 'NGINX_TEMP'
server {
    listen 80;
    server_name _;
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    location / {
        proxy_pass http://app:5000;
    }
}
NGINX_TEMP

    if docker compose version &> /dev/null; then
        docker compose up -d nginx
    else
        docker-compose up -d nginx
    fi

    sleep 3

    # 申请证书
    print_info "申请 Let's Encrypt 证书..."
    docker run -it --rm \
        -v "$(pwd)/certbot/conf:/etc/letsencrypt" \
        -v "$(pwd)/certbot/www:/var/www/certbot" \
        certbot/certbot certonly --webroot \
        -w /var/www/certbot \
        -d "$DOMAIN" \
        --email admin@"$DOMAIN" \
        --agree-tos \
        --no-eff-email

    # 恢复 HTTPS 配置
    print_info "更新 Nginx 配置为 HTTPS..."
    cat > nginx/conf.d/myimg.conf << NGINX_SSL
server {
    listen 80;
    server_name $DOMAIN;
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    location / {
        return 301 https://\$host\$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name $DOMAIN;

    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;

    client_max_body_size 50m;

    location /static/ {
        proxy_pass http://app:5000;
        expires 30d;
    }

    location / {
        proxy_pass http://app:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 120s;
    }
}
NGINX_SSL

    # 重启 Nginx
    if docker compose version &> /dev/null; then
        docker compose restart nginx
    else
        docker-compose restart nginx
    fi

    print_ok "SSL 证书已配置!"
    print_info "访问地址: https://$DOMAIN"
}

#============================================
# 解析参数
#============================================
MODE="${1:-help}"
shift 2>/dev/null || true
DOMAIN=""
PORT=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --domain)
            DOMAIN="$2"
            shift 2
            ;;
        --port)
            PORT="$2"
            shift 2
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            print_error "未知参数: $1"
            show_help
            exit 1
            ;;
    esac
done

#============================================
# 执行
#============================================
case $MODE in
    docker)  deploy_docker ;;
    direct)  deploy_direct ;;
    dev)     deploy_dev ;;
    stop)    stop_docker ;;
    logs)    show_logs ;;
    ssl)     setup_ssl ;;
    help|-h|--help) show_help ;;
    *)
        print_error "未知命令: $MODE"
        show_help
        exit 1
        ;;
esac
