# 手机部署指南（只用手机就能跑起来）

全程只需三步：**下载源码 → 传到 GitHub → 云平台一键部署**。

约 20 分钟完成，之后你在任何手机浏览器都能上传图片、拿 URL 链接。

---

## 第 1 步：下载源码到手机

下载 `myimg-image-hosting.zip`（约 49 KB），保存到手机。

Android 一般存在「下载」目录，iOS 存在「文件」App 里。

用手机自带的解压功能解开，会得到一个 `image-hosting` 文件夹。

---

## 第 2 步：把代码传到 GitHub

这一步是唯一稍麻烦的环节。手机系统不同，方法不同。

### Android：用 Termux（推荐，一次配置长期可用）

1. 应用商店或 [F-Droid](https://f-droid.org/packages/com.termux/) 安装 **Termux**
2. 打开 Termux，依次输入以下命令（每行回车执行）：

```bash
pkg update -y && pkg install -y git unzip
termux-setup-storage
```

手机会弹出存储权限，点「允许」。

3. 解压你下载的压缩包：

```bash
cd ~/storage/downloads
unzip myimg-image-hosting.zip
cd image-hosting
```

4. 在 GitHub 网页版（手机浏览器）创建一个**空仓库**，名字随意（如 `myimg`），**不要**勾选 README、.gitignore、License。

5. 回到 Termux，把代码推上去（把 `你的用户名` 换成你的 GitHub 用户名）：

```bash
git init
git add .
git commit -m "init image hosting"
git branch -M main
git remote add origin https://github.com/你的用户名/myimg.git
git push -u origin main
```

6. 推送时会要求输入账号密码。**密码要填 Personal Access Token**，不是登录密码：
   - 手机浏览器打开 `github.com/settings/tokens`
   - 点 `Generate new token (classic)`
   - Note 随便写，Expiration 选 90 days，勾选 **`repo`** 权限
   - 点最下面 `Generate token`，复制生成的 `ghp_xxxxx` 字符串
   - 回到 Termux，用户名填你的 GitHub 用户名，密码粘贴那个 token

看到 `main -> main` 就成功了。

### iOS：两种办法

**办法 A：a-Shell（免费）**

1. App Store 安装 **a-Shell**
2. 把解压后的 `image-hosting` 文件夹放到「文件」App 的「我的 iPhone → a-Shell」目录下
3. 打开 a-Shell，执行：

```bash
cd ~/Documents/image-hosting   # 路径按实际情况调整，可用 ls 查看
git init
git add .
git commit -m "init"
git branch -M main
git remote add origin https://github.com/你的用户名/myimg.git
git push -u origin main
```

同样需要 Personal Access Token 作为密码（见上面第 6 点）。

**办法 B：GitHub 网页逐个上传（不需要装 App，但比较费手）**

1. 电脑操作会快很多，但纯手机也能做：
2. 手机浏览器打开你的 GitHub 空仓库
3. 点 `Add file → Upload files`
4. 先上传根目录的文件（`run.py`、`requirements.txt`、`Dockerfile` 等）
5. 对于子目录（`app/api/`、`app/templates/` 等），先进到对应目录再上传
6. 目录不存在时，用 `Add file → Create new file`，文件名输入完整路径如 `app/api/images.py`，GitHub 会自动建目录

> 文件一共 35 个，纯手工会很累，建议优先用办法 A。

---

## 第 3 步：云平台部署

### 推荐：Zeabur（中文界面，支持持久卷）

选它是因为**只有它免费层能挂持久卷**，图片不会丢。

1. 手机浏览器打开 [zeabur.com](https://zeabur.com)，用 GitHub 账号登录
2. 点 `新建项目`，地区选「新加坡」或「香港」
3. 点 `部署新服务 → Git 仓库`，授权后选中你的 `myimg` 仓库
4. Zeabur 会自动识别项目里的 `Dockerfile`，直接点部署
5. 等服务变成「运行中」（约 2-3 分钟）

**关键一步：挂载持久卷（不挂的话重启就丢图片）**

6. 点进服务 → `设置 → 卷` → `添加卷`
7. 挂载路径填：`/app/uploads`
8. 再添加一个卷，挂载路径填：`/app/data`（存数据库）
9. 保存后重启服务

**配置环境变量**

10. 服务 → `设置 → 环境变量`，添加这三条：

| 变量名 | 值 |
|--------|-----|
| `FLASK_ENV` | `production` |
| `SECRET_KEY` | 随便一串长随机字符（如 `a8f3k29dm4nx7qp1`） |
| `JWT_SECRET_KEY` | 另一串随机字符（如 `z9w2e5r8t1y4u7i0`） |

11. 服务 → `网络` → 生成域名，会得到一个 `https://xxx.zeabur.app` 的地址

打开这个地址，就是你的图床了。

### 备选：Render（完全免费，但图片可能丢）

项目里已带了 `render.yaml`，Render 能自动读取配置。

1. 手机打开 [render.com](https://render.com)，用 GitHub 登录
2. 点 `New → Web Service`，选你的 `myimg` 仓库
3. Render 会自动读到 `render.yaml`，密钥会自动生成
4. 选 `Free` 套餐，点创建
5. 等 3-5 分钟，得到 `https://xxx.onrender.com` 地址

**注意**：Render 免费层有两个限制——15 分钟没访问会休眠（下次打开慢几十秒）；**没有持久磁盘，容器重启后上传的图片会全部丢失**。

如果要用 Render 长期存图，必须配对象存储，见下面「图片持久化方案」。

---

## 第 4 步：开始使用

1. 打开你的图床地址，点右上「注册」
2. **第一个注册的账号自动成为管理员**
3. 注册后进入 `/dashboard` 管理后台
4. 回到首页，点上传区选图片，或者直接拖拽
5. 上传完成会自动生成链接，可以复制：
   - **URL 直链** —— 发给别人就能看图
   - **Markdown** —— 贴到博客、Notion
   - **HTML** —— 贴到网页
   - **BBCode** —— 贴到论坛

默认是**无损上传**，图片原样保存不改画质。想压缩可以勾选「启用压缩」。

---

## 图片持久化方案（重要）

免费云平台的容器文件系统是临时的。除了 Zeabur 挂持久卷，还有个通用方案：**把图片存到对象存储**。

项目已经内置 S3 兼容存储支持。推荐 **Cloudflare R2**（免费 10 GB 存储 + 无限流量）：

1. 手机打开 [dash.cloudflare.com](https://dash.cloudflare.com)，注册登录
2. 左侧 `R2` → 创建一个存储桶（Bucket），名字如 `myimg`
3. 进入桶 → `Settings` → 开启 `Public access`，记下公开访问域名
4. 回到 R2 首页 → 右侧 `Manage R2 API Tokens` → 创建令牌，权限选「对象读写」
5. 记下 `Access Key ID` 和 `Secret Access Key`

然后在云平台的环境变量里加上：

| 变量名 | 值 |
|--------|-----|
| `CLOUD_BACKUP_ENABLED` | `true` |
| `CLOUD_ENDPOINT` | `https://你的账户ID.r2.cloudflarestorage.com` |
| `CLOUD_ACCESS_KEY` | 第 5 步的 Access Key ID |
| `CLOUD_SECRET_KEY` | 第 5 步的 Secret Access Key |
| `CLOUD_BUCKET` | `myimg` |
| `CLOUD_REGION` | `auto` |

这样每张图上传后都会同时备份到 R2，即使容器重启也不怕。

---

## 常见问题

**Q：手机上能管理图片吗？**
能。`/dashboard` 页面是响应式设计，可以看到统计、图片列表、搜索、删除、改格式，跟电脑上一样。

**Q：上传提示「存储空间不足」**
每个账号默认 1 GB 配额。目前没有做后台改配额的界面，需要的话可以连数据库改 `users` 表的 `storage_quota` 字段（单位是字节）。

**Q：想让别人也能注册用**
默认开放注册。不想开放的话，在环境变量里设置 `REGISTRATION_ENABLED=false`，之后就只有已有账号能登录。

**Q：图片链接里的域名太长/不好看**
在云平台绑定你自己的域名即可。Zeabur 和 Render 都支持自定义域名，绑定后链接就变成 `https://img.你的域名.com/i/xxx`。

**Q：部署失败了怎么办**
先看云平台的构建日志。最常见的原因是 GitHub 仓库里缺文件——确认 `Dockerfile`、`requirements.txt`、`run.py`、`app/` 目录都在仓库根目录下。

**Q：不想折腾了，有没有更简单的**
有。直接用现成图床服务（如路过图床、SM.MS），上传即用，缺点是数据不在自己手里、可能有限制。自己部署的好处是链接永久有效、没有审核、数据完全归你。
