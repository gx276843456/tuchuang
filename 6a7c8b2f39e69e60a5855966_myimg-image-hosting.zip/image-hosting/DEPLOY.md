# MyImg 图床 - 部署指南

本文档提供三种部署方式，按推荐程度排序：

| 方式 | 适合场景 | 难度 | 推荐度 |
|------|---------|------|--------|
| Docker 一键部署 | 有 Docker 环境的服务器 | ★☆☆ | ★★★ |
| 直接部署 | 无 Docker 的 Linux 服务器 | ★★☆ | ★★☆ |
| 开发模式 | 本地开发测试 | ★☆☆ | - |

---

## 方式一：Docker 一键部署（推荐）

### 前提条件
- 服务器已安装 Docker 和 Docker Compose
- 端口 80/443（有域名）或 5000（无域名）可访问

### 步骤

```bash
# 1. 克隆项目到服务器
git clone <your-repo-url> image-hosting
cd image-hosting

# 2. 一键部署
./deploy.sh docker

# 3. 如果有域名，指定域名
./deploy.sh docker --domain img.example.com
```

就这样！脚本会自动：
- 生成随机密钥的 `.env` 配置文件
- 构建 Docker 镜像
- 启动 app + nginx + certbot 三个容器

### 配置 HTTPS（有域名时）

```bash
# 先在 .env 中确认配置，然后申请 SSL 证书
./deploy.sh ssl --domain img.example.com
```

### 常用命令

```bash
./deploy.sh logs     # 查看实时日志
./deploy.sh stop     # 停止服务
./deploy.sh docker   # 重新部署
```

### 手动 Docker 操作

```bash
# 构建并启动
docker compose up -d --build

# 查看状态
docker compose ps

# 查看日志
docker compose logs -f app

# 进入容器
docker compose exec app bash

# 重启
docker compose restart app

# 停止并删除
docker compose down
```

---

## 方式二：直接部署（Gunicorn + Nginx）

### 前提条件
- Linux 服务器（Ubuntu/Debian/CentOS）
- Python 3.9+
- Nginx（可选，用于反向代理）

### 步骤

```bash
# 1. 克隆项目
git clone <your-repo-url> image-hosting
cd image-hosting

# 2. 一键部署（自动创建 systemd 服务 + Nginx 配置）
./deploy.sh direct

# 3. 指定端口
./deploy.sh direct --port 8080
```

### 手动操作

如果不想用脚本，也可以手动部署：

```bash
# 1. 创建虚拟环境
python3 -m venv venv
source venv/bin/activate

# 2. 安装依赖
pip install -r requirements.txt
pip install gunicorn

# 3. 配置环境
cp .env.example .env
# 编辑 .env，修改密钥

# 4. 启动（前台）
gunicorn -c gunicorn_config.py "run:app"

# 5. 后台运行（nohup）
nohup gunicorn -c gunicorn_config.py "run:app" > gunicorn.log 2>&1 &
```

### 配置 systemd 服务

```bash
sudo tee /etc/systemd/system/myimg.service > /dev/null << 'EOF'
[Unit]
Description=MyImg Image Hosting
After=network.target

[Service]
Type=exec
User=www-data
WorkingDirectory=/path/to/image-hosting
EnvironmentFile=/path/to/image-hosting/.env
ExecStart=/path/to/gunicorn -c gunicorn_config.py "run:app"
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable myimg
sudo systemctl start myimg
```

### 配置 Nginx 反向代理

```bash
sudo cp nginx/conf.d/myimg.conf /etc/nginx/conf.d/
# 编辑配置，替换 your-domain.com
sudo nginx -t
sudo systemctl reload nginx
```

### 管理命令

```bash
sudo systemctl status myimg    # 查看状态
sudo systemctl restart myimg   # 重启
sudo systemctl stop myimg      # 停止
journalctl -u myimg -f         # 查看日志
```

---

## 方式三：开发模式

```bash
cd image-hosting
./deploy.sh dev
```

等同于直接运行 `python run.py`，开启 debug 模式。

---

## 配置说明

编辑 `.env` 文件进行配置：

### 必须修改的项

```env
# 生产环境务必修改这两个密钥
SECRET_KEY=<随机字符串>
JWT_SECRET_KEY=<随机字符串>

# 关闭注册（创建账号后改为 false）
REGISTRATION_ENABLED=true
```

生成随机密钥：
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

### 云备份配置（可选）

```env
CLOUD_BACKUP_ENABLED=true
CLOUD_ENDPOINT=https://oss-cn-hangzhou.aliyuncs.com
CLOUD_ACCESS_KEY=your-key
CLOUD_SECRET_KEY=your-secret
CLOUD_BUCKET=your-bucket
CLOUD_REGION=oss-cn-hangzhou
```

### 数据库配置

默认使用 SQLite，无需额外安装。如需使用 PostgreSQL：

```env
DATABASE_URL=postgresql://user:password@localhost:5432/imagehost
```

使用 MySQL：
```env
DATABASE_URL=mysql://user:password@localhost:3306/imagehost
```

需额外安装驱动：
```bash
pip install psycopg2-binary  # PostgreSQL
pip install mysqlclient      # MySQL
```

---

## 数据备份

### 备份

```bash
# 备份数据库 + 上传的图片
tar -czf backup_$(date +%Y%m%d).tar.gz imagehost.db uploads/

# 如果使用 Docker
docker compose exec app tar -czf - uploads/ imagehost.db > backup_$(date +%Y%m%d).tar.gz
```

### 恢复

```bash
# 停止服务
docker compose down   # 或 sudo systemctl stop myimg

# 解压备份
tar -xzf backup_20260812.tar.gz

# 重启服务
docker compose up -d  # 或 sudo systemctl start myimg
```

### 自动备份（crontab）

```bash
# 每天凌晨 3 点自动备份
crontab -e
# 添加:
0 3 * * * cd /path/to/image-hosting && tar -czf /backup/myimg_$(date +\%Y\%m\%d).tar.gz imagehost.db uploads/
```

---

## 性能优化

### Gunicorn 工作进程

```env
# .env 中添加
GUNICORN_WORKERS=5   # 建议 CPU核数*2+1
```

### Nginx 静态文件缓存

静态文件（CSS/JS）默认缓存 30 天。图片缓存 7 天。

### 云存储分担流量

启用云备份后，可在 Nginx 配置中将图片访问直接代理到云端：

```nginx
location /i/ {
    # 如果图片已备份到云端，直接从 CDN 取
    proxy_pass https://your-bucket.oss-cn-hangzhou.aliyuncs.com;
}
```

---

## 安全建议

1. **修改密钥**：生产环境必须修改 `SECRET_KEY` 和 `JWT_SECRET_KEY`
2. **关闭注册**：创建账号后在 `.env` 中设置 `REGISTRATION_ENABLED=false`
3. **启用 HTTPS**：使用 `./deploy.sh ssl` 配置 Let's Encrypt 证书
4. **防火墙**：仅开放 80/443 端口，不要直接暴露 5000
5. **定期备份**：参考上方备份方案

---

## 常见问题

### Q: 上传大图片失败（413 错误）
Nginx 和 Flask 都有上传大小限制。在 `.env` 中修改：
```env
MAX_CONTENT_LENGTH=104857600  # 100MB
```
同时在 Nginx 配置中修改 `client_max_body_size`。

### Q: Docker 构建慢
使用国内镜像加速：
```bash
# /etc/docker/daemon.json
{
  "registry-mirrors": ["https://mirror.ccs.tencentyun.com"]
}
```

### Q: 权限错误
确保 `uploads/` 目录有写权限：
```bash
chmod -R 755 uploads/
chown -R www-data:www-data uploads/  # 直接部署时
```

### Q: 端口被占用
修改 `.env` 或 docker-compose.yml 中的端口映射：
```yaml
ports:
  - "8080:5000"  # 改为 8080
```

### Q: 数据库迁移
如果更新了代码中的模型，需要重建数据库：
```bash
# 开发环境（会清空数据）
rm imagehost.db
python3 -c "from app import create_app; from app.extensions import db; app=create_app(); app.app_context().push(); db.create_all()"

# 生产环境建议使用 Flask-Migrate
flask db init
flask db migrate -m "update"
flask db upgrade
```
