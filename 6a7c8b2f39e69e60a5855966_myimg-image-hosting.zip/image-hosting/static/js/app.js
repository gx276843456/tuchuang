/* ===== 全局工具函数 ===== */
const API = {
    get(url) {
        return fetch(url, {
            headers: this._authHeader(),
        }).then(this._handleResponse);
    },
    post(url, data, isFormData = false) {
        const opts = {
            method: "POST",
            headers: this._authHeader(),
            body: isFormData ? data : JSON.stringify(data),
        };
        if (!isFormData) opts.headers["Content-Type"] = "application/json";
        return fetch(url, opts).then(this._handleResponse);
    },
    patch(url, data) {
        return fetch(url, {
            method: "PATCH",
            headers: { ...this._authHeader(), "Content-Type": "application/json" },
            body: JSON.stringify(data),
        }).then(this._handleResponse);
    },
    delete(url, data) {
        return fetch(url, {
            method: "DELETE",
            headers: { ...this._authHeader(), "Content-Type": "application/json" },
            body: data ? JSON.stringify(data) : undefined,
        }).then(this._handleResponse);
    },
    _authHeader() {
        const token = localStorage.getItem("token");
        return token ? { Authorization: `Bearer ${token}` } : {};
    },
    _handleResponse(res) {
        if (res.status === 401) {
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            if (!window.location.pathname.includes("/login")) {
                window.location.href = "/login";
            }
        }
        return res.json().then((data) => {
            if (!res.ok) throw data;
            return data;
        });
    },
};

function formatSize(bytes) {
    if (!bytes) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    while (bytes >= 1024 && i < units.length - 1) {
        bytes /= 1024;
        i++;
    }
    return `${bytes.toFixed(1)} ${units[i]}`;
}

function formatDate(dateStr) {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    return d.toLocaleDateString("zh-CN", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
    });
}

function showToast(message, type = "info") {
    let container = document.querySelector(".toast-container");
    if (!container) {
        container = document.createElement("div");
        container.className = "toast-container";
        document.body.appendChild(container);
    }
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    const icons = {
        success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2ecc71" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
        error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#e74c3c" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
        info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    };
    toast.innerHTML = `${icons[type] || icons.info}<span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateX(100%)";
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(
        () => showToast("已复制到剪贴板", "success"),
        () => showToast("复制失败", "error")
    );
}

function isLoggedIn() {
    return !!localStorage.getItem("token");
}

function getCurrentUser() {
    const userStr = localStorage.getItem("user");
    return userStr ? JSON.parse(userStr) : null;
}

/* ===== 导航栏渲染 ===== */
function renderNavbar() {
    const navLinks = document.getElementById("navLinks");
    if (!navLinks) return;

    if (isLoggedIn()) {
        const user = getCurrentUser();
        const initial = user ? user.username[0].toUpperCase() : "?";
        navLinks.innerHTML = `
            <a href="/dashboard">管理后台</a>
            <div class="nav-user">
                <div class="nav-avatar" title="${user ? user.username : ""}">${initial}</div>
                <a href="javascript:void(0)" class="btn-logout" onclick="logout()">退出</a>
            </div>
        `;
    } else {
        navLinks.innerHTML = `
            <a href="/login">登录</a>
            <a href="/register">注册</a>
        `;
    }
}

function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/";
}

/* ===== 页面初始化 ===== */
document.addEventListener("DOMContentLoaded", () => {
    renderNavbar();
});
