# MyImg - 个人图床

基于 Python Flask 的全功能个人图床系统，支持图片上传、自动压缩、格式转换、云备份、用户认证和数据统计。

## 功能特性

- **图片上传**：支持单张/批量上传，拖拽上传，自动生成缩略图
- **自动压缩**：上传时自动压缩图片，节省存储空间
- **格式转换**：支持 JPG / PNG / WEBP 互转
- **云备份**：支持 S3 兼容的对象存储（阿里云 OSS / 腾讯云 COS / AWS S3 / MinIO）
- **用户认证**：JWT 鉴权，支持注册/登录/修改密码
- **图片管理**：列表浏览、搜索排序、批量删除、公开/私密切换
- **数据统计**：存储用量、上传趋势、格式分布、浏览量统计
- **访问控制**：私密图片需登录才能访问
- **链接分享**：自动生成直链 / Markdown / HTML 代码

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境

```bash
cp .env.example .env
# 编辑 .env 修改密钥和配置
```

### 3. 启动服务

```bash
python run.py
```

访问 `http://localhost:5000` 即可使用。第一个注册的用户自动成为管理员。

## 项目结构

```
image-hosting/
├── app/
│   ├── __init__.py          # 应用工厂
│   ├── config.py            # 配置
│   ├── extensions.py        # Flask 扩展
│   ├── models.py            # 数据模型
│   ├── main.py              # 主路由（页面+图片访问）
│   ├── auth/
│   │   └── routes.py        # 认证 API
│   ├── api/
│   │   ├── images.py        # 图片 API
│   │   └── stats.py         # 统计 API
│   ├── services/
│   │   ├── storage.py       # 存储服务（本地+云）
│   │   └── image_processor.py  # 图片处理
│   └── templates/           # 页面模板
├── static/
│   ├── css/style.css        # 样式
│   └── js/app.js            # 前端逻辑
├── uploads/                 # 本地存储
├── run.py                   # 启动入口
├── requirements.txt         # 依赖
├── .env.example             # 配置模板
└── README.md
```

## API 文档

### 认证

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/auth/register` | 用户注册 |
| POST | `/api/auth/login` | 用户登录 |
| GET | `/api/auth/me` | 获取当前用户 |
| POST | `/api/auth/change-password` | 修改密码 |

### 图片

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/images/upload` | 上传图片 |
| POST | `/api/images/upload/batch` | 批量上传 |
| GET | `/api/images` | 图片列表 |
| GET | `/api/images/<id>` | 图片详情 |
| DELETE | `/api/images/<id>` | 删除图片 |
| POST | `/api/images/batch/delete` | 批量删除 |
| POST | `/api/images/<id>/convert` | 格式转换 |
| PATCH | `/api/images/<id>/toggle-privacy` | 切换私密 |

### 统计

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/stats/overview` | 数据概览 |
| GET | `/api/stats/upload-trend` | 上传趋势 |
| GET | `/api/stats/format-distribution` | 格式分布 |
| GET | `/api/stats/recent` | 最近上传 |

### 图片访问

| 路径 | 说明 |
|------|------|
| `/i/<public_id>` | 访问图片 |
| `/i/<public_id>?thumb=1` | 访问缩略图 |
| `/api/images/<public_id>/download` | 下载图片 |

## 云备份配置

在 `.env` 中设置：

```env
CLOUD_BACKUP_ENABLED=true
CLOUD_ENDPOINT=https://your-endpoint
CLOUD_ACCESS_KEY=your-key
CLOUD_SECRET_KEY=your-secret
CLOUD_BUCKET=your-bucket
CLOUD_REGION=your-region
```

支持的对象存储：
- 阿里云 OSS
- 腾讯云 COS
- AWS S3
- MinIO
- 其他 S3 兼容存储

## 技术栈

- **后端**：Flask 3.0, SQLAlchemy, Flask-JWT-Extended
- **图片处理**：Pillow
- **云存储**：Boto3 (S3)
- **前端**：原生 HTML/CSS/JS，无框架依赖
- **数据库**：SQLite（可切换 PostgreSQL/MySQL）
