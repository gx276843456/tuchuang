"""Gunicorn 生产级配置"""
import os
import multiprocessing

# 绑定地址
bind = "0.0.0.0:5000"

# 工作进程数 (CPU 核数 * 2 + 1)
workers = int(os.environ.get("GUNICORN_WORKERS", multiprocessing.cpu_count() * 2 + 1))

# 每个工作进程的并发请求数
worker_connections = 1000

# 工作模式
worker_class = "sync"

# 超时设置（秒）- 上传大图需要更长超时
timeout = 120

# 优雅重启超时
graceful_timeout = 30

# 长连接
keepalive = 5

# 最大请求数（达到后工作进程重启，防止内存泄漏）
max_requests = 1000
max_requests_jitter = 50

# 预加载应用（节省内存，加快启动）
preload_app = True

# 日志
accesslog = "-"  # 输出到 stdout
errorlog = "-"   # 输出到 stderr
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# 进程名
proc_name = "myimg"

# 文件上传大小限制（字节）
limit_request_line = 8190
limit_request_field_size = 8190
limit_request_fields = 100
